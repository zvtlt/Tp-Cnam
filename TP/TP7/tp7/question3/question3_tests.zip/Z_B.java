package question3;


public class Z_B extends Z_A{
  
  public void q(){
  }
  
  public void p(float x){
  }
  
  public void z(){}
  
  public  Object clone() throws CloneNotSupportedException{return null;}
  
  protected void finalize() throws java.lang.Throwable{}

}