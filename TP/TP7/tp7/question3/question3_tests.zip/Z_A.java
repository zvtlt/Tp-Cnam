 package question3;
 
 
 public class Z_A{
   public void p(){
   }
   public void p(int x){
   }
   public void q(){
   }
   
   protected void z(){}
   
 
 
 }
 